#include <linux/module.h> 
 
static int __init my_module_init(void)
{
	printk(KERN_ALERT"hello world!\n");
	return 0;
}
 
static void __exit my_module_exit(void)
{
}
 
module_init(my_module_init);
module_exit(my_module_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Miao Hao");
